export let apiKey = "ExampleApiKey";

export let example = "SecondVariable";

export default "DefaultExportLine";
